explainxkcd Chrome Extension
============================

Don't always understand xkcd? Too lazy to look up the matching article on [explainxkcd](http://www.explainxkcd.com/wiki/)?

This is the extension for you then, my friend.